public class Person {
    String name;
    String surname;
    String patronymic;
}
