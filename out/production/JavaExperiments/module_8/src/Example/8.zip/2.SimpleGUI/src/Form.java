import javax.swing.*;

public class Form {

    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JPanel rootPanel;
    private JButton setButton;

    public JPanel getRootPanel() {
        return rootPanel;
    }




}
